//
//  oDesk.h
//  oDeskTimer
//
//  Created by Roman Sidorakin on 08.05.12.
//  Copyright (c) 2012 Rus Wizards. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface oDesk : NSObject
@property (nonatomic,retain) NSString* login;
-(NSString *) login:(NSString*) name password:(NSString*) password;
-(NSDictionary *) todayTotalTime:(NSString**)outTotalTime;
+(NSString*) convertTimeToString:(CFTimeInterval) time;
+(CFTimeInterval)convertToTime:(NSString *)time;
@end
